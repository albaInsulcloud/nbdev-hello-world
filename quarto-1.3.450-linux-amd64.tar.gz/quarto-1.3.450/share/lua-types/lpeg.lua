---@meta

---@module 'lpeg'

lpeg = {}


return lpeg