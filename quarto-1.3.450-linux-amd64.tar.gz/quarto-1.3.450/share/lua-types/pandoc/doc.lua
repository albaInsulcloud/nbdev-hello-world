---@meta

--[[
  Pandoc reflowable document: https://pandoc.org/lua-filters.html#type-doc

  TODO: write fields and methods
]]
---@class pandoc.Doc
