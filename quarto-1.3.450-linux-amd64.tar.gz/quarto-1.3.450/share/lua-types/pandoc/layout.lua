---@meta

---@module 'pandoc.layout'

pandoc.layout = {}


return pandoc.layout